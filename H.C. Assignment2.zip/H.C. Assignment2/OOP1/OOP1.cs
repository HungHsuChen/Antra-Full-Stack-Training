﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H.C._Assignment2
{
    public abstract class Person
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime Birthday { get; set; }

        public abstract void Behavior();

    }

    public class Student: Person
    {
        public double GPA { get; set; }
        private string Evaluation { get; set; }
        public List<int> CourseId { get; set; }
        public List<char> Grades { get; set; }

        public override void Behavior()
        {
            Console.WriteLine("Student go to school and study.");
        }
    }

    public class Instructor: Person
    {
        public decimal Salary { get; set; }
        public bool HeadOfDepartment { get; set; }
        public DateTime JoinDate { get; set; }

        public override void Behavior()
        {
            Console.WriteLine("Instructor go to school and teach.");
        }

    }

    public class Course
    {
        public int CourseId { get; set; }
        public string CourseName { get; set; }
        public List<int> StudentId { get; set; }
    }

    public class Department
    {
        public string DpName { set; get; }
        public int DpId { get; set; }
        public int HeadId { get; set; }
        public decimal Budget { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public List<int> OfferCourses { get; set; }
    }
}
