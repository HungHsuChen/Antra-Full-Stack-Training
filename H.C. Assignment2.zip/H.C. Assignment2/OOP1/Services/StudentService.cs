﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H.C._Assignment2.OOP1.Services
{
    public class StudentService : IPersonService<Student>
    {
        public int CalculateAge(Student obj)
        {
            DateTime today = DateTime.Today;
            TimeSpan age = today.Subtract(obj.Birthday);
            return (age.Days / 365);
        }

        public decimal CalculateSalary(Student obj)
        {
            return 0;
        }

        public double CalculateGPA(Student obj)
        {
            double sum = 0;
            foreach(char grade in obj.Grades)
            {
                switch (grade)
                {
                    case 'A':
                        sum += 4.0;
                        break;
                    case 'B':
                        sum += 3.0;
                        break;
                    case 'C':
                        sum += 2.0;
                        break;
                    case 'F':
                        sum += 0.0;
                        break;
                    default:
                        break;
                }
            }
            return (sum / obj.Grades.Count);
        }
    }
}
