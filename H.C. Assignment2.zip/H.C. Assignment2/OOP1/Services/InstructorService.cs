﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H.C._Assignment2.OOP1.Services
{
    public class InstructorServices : IPersonService<Instructor>
    {
        public DateTime today = DateTime.Today;

        public int CalculateAge(Instructor obj)
        {
            TimeSpan age = today.Subtract(obj.Birthday);
            return (age.Days / 365);
        }

        public decimal CalculateSalary(Instructor obj)
        {
            TimeSpan exp = today.Subtract(obj.JoinDate);
            decimal bonus = (exp.Days / 365) * 500;
            return obj.Salary + bonus;
        }
    }
}
