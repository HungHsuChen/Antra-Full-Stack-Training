﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H.C._Assignment2.OOP1
{
    public interface IPersonService<T> where T: class
    {
        int CalculateAge(T obj);
        decimal CalculateSalary(T obj);

    }
}
