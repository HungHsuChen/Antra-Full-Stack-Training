﻿using System;
using System.Collections.Generic;

namespace H.C._Assignment2
{
    public static class WorkingWithMethods
    {
        public static int[] GenerateNumbers(int len)
        {
            List<int> numList = new List<int>();
            for (int i = 0; i < len; i++)
            {
                numList.Add(i + 1);
            }
            return numList.ToArray();
        }

        public static int[] Reverse(int[] arr)
        {
            Array.Reverse(arr);
            return arr;
        }

        public static void PrintNumbers(int[] arr)
        {
            foreach (int i in arr)
            {
                Console.Write(i + " ");
            }
        }

        public static int Fibonacci(int n)
        {
            if (n == 1 || n == 2)
            {
                return 1;
            }

            return Fibonacci(n - 1) + Fibonacci(n - 2);
        }

        public static void WorkingDays(DateTime date1, DateTime date2)
        {
            if(date1.CompareTo(date2) > 0)
            {
                DateTime temp = date1;
                date1 = date2;
                date2 = temp;
            }

            int workDayCount = 0;
            int daysBetween = date2.Subtract(date1).Days;
            for (int i = 0; i <= daysBetween; i++)
            {
                if(date1.DayOfWeek != DayOfWeek.Sunday & date1.DayOfWeek != DayOfWeek.Saturday & !(CheckHoliday(date1)))
                {
                    workDayCount += 1;
                }
                date1 = date1.AddDays(1);
            }
            Console.WriteLine(workDayCount);
        }

        public static bool CheckHoliday(DateTime date)
        {
            int month = date.Month;
            int day = date.Day;

            if (month == 1 & (day == 1 || day == 18 || day == 20))
            {
                return true;
            }
            else if (month == 2 & day == 15)
            {
                return true;
            }
            else if (month == 5 & day == 31)
            {
                return true;
            }
            else if (month == 6 & day == 18)
            {
                return true;
            }
            else if (month == 7 & day == 5)
            {
                return true;
            }
            else if (month == 9 & day == 6)
            {
                return true;
            }
            else if (month == 10 & day == 11)
            {
                return true;
            }
            else if (month == 11 & (day == 11 || day == 25))
            {
                return true;
            }
            else if (month == 12 & day == 24)
            {
                return true;
            }
            return false;

        }

    }
}
