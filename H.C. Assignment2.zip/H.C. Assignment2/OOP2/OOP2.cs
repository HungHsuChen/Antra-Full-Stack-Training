﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H.C._Assignment2.OOP2
{
    public class Color
    {
        public int Red { get; set; }
        public int Green { get; set; }
        public int Blue { get; set; }
        public int Alpha { get; set; }

        public Color(int red, int green, int blue, int alpha)
        {
            Red = red;
            Green = green;
            Blue = blue;
            Alpha = alpha;
        }

        public Color(int red, int green, int blue)
        {
            Red = red;
            Green = green;
            Blue = blue;
            Alpha = 255;
        }

        public int GetGrayScale(Color obj)
        {
            return (obj.Red + obj.Green + obj.Blue)/3;
        }
    }

    public class Ball
    {
        public int Size { get; set; }
        public Color BallColor { get; set; }
        private int Thrown { get; set; }

        public Ball(int size, Color ballColor, int thrown)
        {
            Size = size;
            BallColor = ballColor;
            Thrown = thrown;
        }

        public Ball(int size, Color ballColor)
        {
            Size = size;
            BallColor = ballColor;
            Thrown = 0;
        }

        public void Pop()
        {
            Size = 0;
        }

        public void Throw()
        {
            if (Size == 0)
            {
                return;
            }
            Thrown += 1;
        }

        public int GetThrown()
        {
            return Thrown;
        }

    }
}
