﻿using H.C._Assignment2.OOP2;
using H.C._Assignment2.OOP3;
using System;

namespace H.C._Assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            /* 1. What are the six combinations of access modifier keywords and what do they do?
             * Public, Private, Proteted, internal, protected intetrnal, private protected
             * They use to limit the accessbility of type and member
             * 
             * 2. What is the difference between the static, const, and readonly keywords when applied to a type member?
             * Const can't be modified or changed once it's defined.
             * Readonly can be static, can be declared in the constructer class.
             * Static requier all the class members to be static if a class is static.
             * 
             * 3. What does a constructor do?
             * A constructor is a method whose name is the same as the name of its type. Its method signature includes only the method name and its parameter list; it does not include a return type.
             * 
             * 4. Why is the partial keyword useful?
             * When working on large projects, spreading a class over separate files enables multiple programmers to work on it at the same time.
             * 
             * 5. What is a tuple?
             * A lightweight data structure that use to group multiple data elements.
             * It's a reference type
             * 
             * 6. What does the C# record keyword do?
             * A record is a class or struct that provides special syntax and behavior for working with data models.
             * 
             * 7. What does overloading and overriding mean?
             * Overriding methods in base class and its subclasses share the same method name and same input parameters.
             * Overloading Methods in same class share the same method name, but different input parameters.
             * 
             * 8. What is the difference between a field and a property?
             * A private field that stores the data exposed by a public property is called a backing store or backing field.
             * 
             * 9. How do you make a method parameter optional?
             * By assigning default value or using method overloading
             * 
             * 10. What is an interface and how is it different from abstract class?
             * Abstract class provide a base class to its subclasses -- clear class hierarchy
             * Interface defines common behaviors or functionalities that can be implemented by any class
             * 
             * 11. What accessibility level are members of an interface? 
             * Interface memebrs are public by default.
             * 
             * 12. True/False. Polymorphism allows derived classes to provide different implementations
             * of the same method
             * T
             * 
             * 13. True/False. The override keyword is used to indicate that a method in a derived class is providing its own implementation of a method.
             * T
             * 
             * 14. True/False. The new keyword is used to indicate that a method in a derived class is providing its own implementation of a method.
             * F
             * 
             * 15. True/False. Abstract methods can be used in a normal (non-abstract) class. 
             * F
             * 
             * 16. True/False. Normal (non-abstract) methods can be used in an abstract class.
             * F
             * 
             * 17. True/False. Derived classes can override methods that were virtual in the base class.
             * T
             * 
             * 18. True/False. Derived classes can override methods that were abstract in the base class.
             * T
             * 
             * 19. True/False. In a derived class, you can override a method that was neither virtual non abstract in the base class
             * T, override method
             * 
             * 20.True/False. A class that implements an interface does not have to provide an implementation for all of the members of the interface. 
             * F
             * 
             * 21. True/False. A class that implements an interface is allowed to have other members that aren’t defined in the interface
             * T
             * 
             * 22. True/False. A class can have more than one base class. 
             * F
             * 
             * 23. True/False. A class can implement more than one interface. 
             * T
             */

            //---------------------------------------------------------------------------------------------------

            //int[] numbers = WorkingWithMethods.GenerateNumbers(20);
            //WorkingWithMethods.Reverse(numbers);
            //WorkingWithMethods.PrintNumbers(numbers);

            //---------------------------------------------------------------------------------------------------

            //for (int i = 1; i <= 10; i++)
            //{
            //    Console.Write(WorkingWithMethods.Fibonacci(i) + " ");
            //}

            //---------------------------------------------------------------------------------------------------

            //DateTime day1 = DateTime.Parse(Console.ReadLine());
            //DateTime day2 = DateTime.Parse(Console.ReadLine());

            //WorkingWithMethods.WorkingDays(day1, day2);

            //---------------------------------------------------------------------------------------------------

            //Student s1 = new Student();
            //Instructor i1 = new Instructor();
            //i1.Id = 1;
            //i1.Name = "Tom";
            //i1.Salary = 5000;

            //s1.Behavior();
            //i1.Behavior();

            //---------------------------------------------------------------------------------------------------

            //Color red = new Color(255,0,0);
            //Color blue = new Color(0, 0, 255);

            //Ball redBall = new Ball(1, red);
            //Ball blueBall = new Ball(2, blue);

            //for (int i = 0; i < 5; i++)
            //{
            //    if(blueBall.GetThrown() > 3)
            //    {
            //        blueBall.Pop();
            //    }
            //    redBall.Throw();
            //    blueBall.Throw();
            //}
            //Console.WriteLine(redBall.GetThrown() + " " + blueBall.GetThrown());
            //Console.WriteLine(redBall.Size + " " + blueBall.Size);

            //---------------------------------------------------------------------------------------------------

            Customer c = new Customer();
            c.FirstName = "I'm";
            c.LastName = "Tom";

            Console.WriteLine(c.Name);

            Order o1 = new Order();
            o1.OrderDate = DateTime.Parse("2021/11/1");
            Console.WriteLine(o1.OrderNumber);

            Order o2 = new Order();
            c.AddOrder(o1);
            c.AddOrder(o2);

            foreach(Order order in c.Orders)
            {
                Console.WriteLine(order.OrderNumber);
            }
        }
    }
}
