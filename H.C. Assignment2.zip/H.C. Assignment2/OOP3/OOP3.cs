﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H.C._Assignment2.OOP3
{
    public class Customer
    {
        public List<Order> Orders { get; set; }
        public string FirstName { get; set; }
        public string  LastName { get; set; }
        public string Name
        {
            get
            {
                return FirstName + " " + LastName;
            }
        }
        public string Email { get; set; }

        public Customer()
        {
            Orders = new List<Order>();
        }

        public void AddOrder(Order o)
        {
            if (o == null)
            {
                return;
            }
            if(Orders.Count < 1)
            {
                Orders.Add(o);
                return;
            }
            for(int i = 0; i < Orders.Count; i++)
            {
                if (Orders[i].OrderNumber.Equals(o.OrderNumber))
                {
                    Orders.Remove(Orders[i]);
                }
            }
            Orders.Add(o);
        }

    }

    public class Order
    {
        public Guid OrderNumber { get; }
        private DateTime orderDate;
        public DateTime OrderDate
        {
            get
            {
                return orderDate;
            }

            set 
            { 
                if(value.CompareTo(DateTime.Today) > 0)
                {
                    return;
                }
                else
                {
                    orderDate = value;
                }
            } 
        }

        public Order()
        {
            OrderNumber = Guid.NewGuid();
        }

    }
}
