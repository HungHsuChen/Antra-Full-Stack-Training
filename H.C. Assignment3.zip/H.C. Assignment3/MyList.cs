﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H.C._Assignment3
{
    public class MyList<T>
    {
        T[] itemList;

        public void Add(T t)
        {
            T[] temp = new T[itemList.Length + 1];
            for (int i = 0; i < itemList.Length; i++)
            {
                temp[i] = itemList[i];
            }
            temp[itemList.Length] = t;
            itemList = temp;
        }

        public T[] Remove(int index)
        {
            T[] temp = new T[itemList.Length - 1];
            for (int i = 0; i < itemList.Length; i++)
            {
                if(i == index)
                {
                    continue;
                }
                temp[i] = itemList[i];
            }
            itemList = temp;
            return itemList;
        }

        public bool Contains(T t)
        {
            foreach (T item in itemList)
            {
                if (item.Equals(t))
                {
                    return true;
                }
            }
            return false;
        }

        public void Clear()
        {
            T[] temp = new T[] { };
            itemList = temp;
        }

        public void InsertAt(T t, int index)
        {
            T[] temp = new T[itemList.Length + 1];
            int j = 0;
            for (int i = 0; i < itemList.Length; i++)
            {
                if (i == index)
                {
                    temp[i] = t;
                    i--;
                }
                else
                {
                    temp[j] = itemList[i];
                }
                
                j++;
            }
            itemList = temp;
        }

        public void DeleteAt(int index)
        {
            T[] temp = new T[itemList.Length - 1];
            for (int i = 0; i < itemList.Length; i++)
            {
                if (i == index)
                {
                    continue;
                }
                temp[i] = itemList[i];
            }
            itemList = temp;
        }

        public T Find(int index)
        {
            return itemList[index];
        }

    }
}
