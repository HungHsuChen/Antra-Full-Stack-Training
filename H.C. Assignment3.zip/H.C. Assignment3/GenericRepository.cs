﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H.C._Assignment3
{
    class GenericRepository<T> : IRepository<T>
    {
        IEnumerable<T> items;

        public void Add(T t)
        {
            items = items.Append(t);
        }

        public IEnumerable<T> GetAll()
        {
            return items;
        }

        public T GetById(int id)
        {
            return items.ElementAt(id);
        }

        public void Remove(T t)
        {
            IEnumerable<T> temp = null;
            foreach (T item in items)
            {
                if (item.Equals(t))
                {
                    continue;
                }
                else
                {
                    temp = temp.Append(item);
                }
            }
            items = temp;
        }

        public void Save()
        {
            throw new NotImplementedException();
        }
    }
}
