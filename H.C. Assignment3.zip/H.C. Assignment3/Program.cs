﻿using System;

namespace H.C._Assignment3
{
    class Program
    {
        static void Main(string[] args)
        {
            /* 1. Describe the problem generics address.
             * Type safty, less code
             * 
             * 2. How would you create a list of strings, using the generic List class?
             * List<string> newStringList = new List<string>();
             * 
             * 3. How many generic type parameters does the Dictionary class have?
             * 2, a TKey and TValue
             * 
             * 4. True/False. When a generic class has multiple type parameters, they must all match.
             * F
             * 
             * 5. What method is used to add items to a List object?
             * List.Add()
             * 
             * 6. Name two methods that cause items to be removed from a List.
             * List.Remove(), List.Clear()
             * 
             * 7. How do you indicate that a class has a generic type parameter?
             * <>
             * 
             * 8. True/False. Generic classes can only have one generic type parameter.
             * F
             * 
             * 9. True/False. Generic type constraints limit what can be used for the generic type.
             * T
             * 
             * 10. True/False. Constraints let you use the methods of the thing you are constraining to.
             * T
             */


        }
    }
}
