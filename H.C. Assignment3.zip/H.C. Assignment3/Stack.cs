﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H.C._Assignment3
{
    public class MyStack<T> 
    {
        T[] itemStack;

        public int Count()
        {
            int count = 0;
            foreach (var v in itemStack)
            {
                count += 1;
            }
            return count;
        }

        public T[] Pop()
        {
            T[] temp = new T[itemStack.Length-1];
            for (int i = 1; i < itemStack.Length - 1; i++)
            {
                temp[i - 1] = itemStack[i];
            }
            return temp;
        }

        public void Push(T t)
        {
            T[] temp = new T[itemStack.Length + 1];
            temp[0] = t;
            for (int i = 1; i < itemStack.Length; i++)
            {
                temp[i] = itemStack[i - 1];
            }
            itemStack = temp;
        }

    }
}
