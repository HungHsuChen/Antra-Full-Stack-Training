﻿using System;
using System.Collections.Generic;
using System.Text;

namespace H.C._Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            /* 1. What type would you choose for the following “numbers”?
             * byte     A person’s telephone number
             * float    A person’s height
             * byte     A person’s age
             * char     A person’s gender (Male, Female, Prefer Not To Answer)
             * decimal  A person’s salary
             * byte     A book’s ISBN 
             * decimal  A book’s price 
             * float      book’s shipping weight 
             * ulong    A country’s population
             * ulong    The number of stars in the universe
             * ushort   The number of employees in each of the small or medium businesses in the United Kingdom (up to about 50,000 employees per business) 
             * 
             * 2. What are the difference between value type and reference type variables? What is boxing and unboxing?
             * Value type hold the value itself while reference hold the memory address/ reference for the value.
             * Boxing is to convert a value type to reference type
             * Unboxing is to convert a reference type to value type
             * 
             * 3. What is meant by the terms managed resource and unmanaged resource in .NET
             * Managed resources are those that are pure .NET code and managed by the runtime and are under its direct control.
             * Unmanaged resources are those that are not. File handles, pinned memory, COM objects, database connections etc.
             * (didn't mention in class)
             * 
             * 4. Whats the purpose of Garbage Collector in .NET? 
             * It manages the allocation and release of memory for the app
             * 
             */

            //---------------------------------------------------------------------------------------------------------

            //_02UnderstandingTypes type = new _02UnderstandingTypes();
            //type.PrintTypes();

            //---------------------------------------------------------------------------------------------------------

            //Console.WriteLine("Enter an interger for century");
            //int century = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine($"{century} centuries = {century * 100} years = {century * 36524} days = " +
            //    $"{century * 876576} hours = {century * 52594560} minutes = {century * 3155673600} seconds = " +
            //    $"{century * 3155673600000} milliseconds = {century * 3155673600000000} microseconds = " +
            //    $"{century * 3155673600000000000} nanoseconds");

            //---------------------------------------------------------------------------------------------------------

            /* 1. What happens when you divide an int variable by 0? 
             * An error, division by constant zero
             * 
             * 2. What happens when you divide a double variable by 0?
             * Infinity
             * 
             * 3. What happens when you overflow an int variable, that is, set it to a value beyond its range?
             * An error, the value can't be convert to int
             * 
             * 4. What is the difference between x = y++; and x = ++y;? 
             *  x = y++ : x equals to y, then y + 1
             *  x = ++y : x equals to y + 1
             * 
             * 5. What is the difference between break, continue, and return when used inside a loop statement? 
             * Break will stop the loop, Continue will skip the current iteration, return will stop the current method as a whole
             * 
             * 6. What are the three parts of a for statement and which of them are required? 
             * Initialization, condition, and iterator. The Condition is required
             * 
             * 7. What is the difference between the = and == operators?
             * = use to assign value to a varaible, == use to check if values are equal
             * 
             * 8. Does the following statement compile? for ( ; true; ) ; 
             * Yea it does, it will loop forever and does nothing
             * 
             * 9. What does the underscore _ represent in a switch expression?
             * It use to signify if anything match
             * 
             * 10. What interface must an object implement to be enumerated over by using the foreach statement?
             * IEnumerable interface
             */

            //---------------------------------------------------------------------------------------------------------

            //Chapter03Excercise03.FizzBuzz();

            //---------------------------------------------------------------------------------------------------------

            //This loop will never end becuase byte can only take num up to 255, when i reaches 255, i will go back to 0
            //int max = 500;
            //for (byte i = 0; i < max; i++)
            //{
            //    Console.WriteLine(i);
            //    if (i == byte.MaxValue){
            //        Console.WriteLine("The iterator reached its max value.");
            //        break;
            //    }
            //}

            //---------------------------------------------------------------------------------------------------------

            //Chapter03Excercise03.PrintAPyramid();

            //---------------------------------------------------------------------------------------------------------

            //Chapter03Excercise03.GuessGame();

            //---------------------------------------------------------------------------------------------------------

            //Chapter03Excercise03.DaysOld();

            //---------------------------------------------------------------------------------------------------------

            //Chapter03Excercise03.Greeting();

            //---------------------------------------------------------------------------------------------------------

            //Chapter03Excercise03.Count24();

            //---------------------------------------------------------------------------------------------------------

            /* 1. When to use String vs. StringBuilder in C# ?
             * Use StringBuilder when the string will be changed later.
             * Use String to keep the string immutable
             * 
             * 2. What is the base class for all arrays in C#?
             * The Array class
             * 
             * 3. How do you sort an array in C#?
             * Use Array.Sort()
             * 
             * 4. What property of an array object can be used to get the total number of elements in an array?
             * Array.Length()
             * 
             * 5. Can you store multiple data types in System.Array?
             * Yes
             * 
             * 6. What’s the difference between the System.Array.CopyTo() and System.Array.Clone()?
             * Copyto copy the value from an one-dimension array to another one-dimension array.
             * Clone create a copy of an array.
             * 
             */

            //---------------------------------------------------------------------------------------------------------

            //int[] arr = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            //foreach (int i in arr)
            //{
            //    Console.Write($"{i} ");
            //}
            //Console.Write("\n");

            //int[] arrCopy = Chapter03Excercise03.CopyArray(arr);

            //foreach (int i in arrCopy)
            //{
            //    Console.Write($"{i} ");
            //}

            //---------------------------------------------------------------------------------------------------------

            //Chapter03Excercise03.list();

            //---------------------------------------------------------------------------------------------------------

            //int[] primeNums = Chapter03Excercise03.FindPrimesInRange(1, 100);
            //foreach(int i in primeNums)
            //{
            //    Console.Write($"{i},");
            //}

            //---------------------------------------------------------------------------------------------------------

            //int[] arr = new int[] { 1,2,3,4,5 };


            //int[] sum = Chapter03Excercise03.rotateSum(arr, 3);

            //foreach (int i in sum)
            //{
            //    Console.Write($"{i},");
            //}

            //---------------------------------------------------------------------------------------------------------

            //int[] arr = new int[] { 4, 4, 4, 4 };
            //int[] seq = Chapter03Excercise03.longestSequence(arr);

            //foreach (int i in seq)
            //{
            //    Console.Write($"{i},");
            //}

            //---------------------------------------------------------------------------------------------------------

            //int[] arr = new int[] { 4 };
            //int mostFre = Chapter03Excercise03.mostFrequentNum(arr);

            //Console.WriteLine(mostFre);

            //---------------------------------------------------------------------------------------------------------

            //Console.WriteLine(Chapter03Excercise03.reverse1("sample"));
            //Chapter03Excercise03.reverse2("SAMPLE");

            //---------------------------------------------------------------------------------------------------------

            //Chapter03Excercise03.reverseSentence("The quick brown fox jumps over the lazy dog /Yes! Really!!!/.");

            //---------------------------------------------------------------------------------------------------------

            //Chapter03Excercise03.palindromes("Hi,exe? ABBA! Hog fully a string: ExE. Bob");

            //---------------------------------------------------------------------------------------------------------

            //List<string> url = Chapter03Excercise03.parseURL("www.apple.com");

            //foreach(string word in url)
            //{
            //    Console.WriteLine(word);
            //}

        }
    }
}
