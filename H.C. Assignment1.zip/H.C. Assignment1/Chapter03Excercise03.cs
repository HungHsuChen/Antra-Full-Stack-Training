﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace H.C._Assignment1
{
    static class Chapter03Excercise03
    {

        public static void FizzBuzz()
        {
            byte upto = 100;

            for (int i = 1; i <= upto; i++)
            {
                if (i % 3 == 0 &  i % 5 == 0)
                {
                    Console.WriteLine("fizzbuzz");
                } 
                else if (i % 3 == 0)
                {
                    Console.WriteLine("fizz");
                }
                else if (i % 5 == 0)
                {
                    Console.WriteLine("buzz");
                } 
                else
                {
                    Console.WriteLine(i);
                }
            }
            
        }

        public static void PrintAPyramid()
        {
            for (int i = 0; i < 5; i++)
            {
                for (int space = 4 - i; space > 0; space--)
                {
                    Console.Write(" ");
                }
                for (int star = 1 + 2 * i; star > 0; star--)
                {
                    Console.Write("*");
                }
                Console.Write("\n");
            }
        }

        public static void GuessGame()
        {
            int correctNumber = new Random().Next(3) + 1;

            bool win = false;
            while (win == false)
            {
                Console.WriteLine("Please enter a number between 1 to 3");
                int guessedNumber = int.Parse(Console.ReadLine());

                if (guessedNumber < 1 || guessedNumber > 3)
                {
                    Console.WriteLine("The number is out of range, please enter a number between 1 to 3.");
                    continue;
                }
                if (guessedNumber == correctNumber)
                {
                    win = true;
                    Console.WriteLine("You guessed the correct Number!");
                    continue;
                }
                if (guessedNumber < correctNumber)
                {
                    Console.WriteLine("Low");
                }
                if (guessedNumber > correctNumber)
                {
                    Console.WriteLine("High");
                }

            }
        }

        public static void DaysOld()
        {
            DateTime birthday = DateTime.Parse(Console.ReadLine());
            DateTime today = DateTime.Today;
            int days = today.Subtract(birthday).Days;
            Console.WriteLine($"The person is {days} days old.");
            int daysToNextAnniversary = 10000 - (days % 10000);
            Console.WriteLine($"There are {daysToNextAnniversary} days to the next 10,000 day anniversary.");
        }

        public static void Greeting()
        {
            DateTime now = DateTime.Now;
            int hour = now.Hour;

            if (hour >= 6 & hour < 12)
            {
                Console.WriteLine("Good Morning");
            }
            if (hour >=12 & hour <18)
            {
                Console.WriteLine("Good Afternoon");
            }
            if (hour >= 18 & hour < 21)
            {
                Console.WriteLine("Good Evening");
            }
            if (hour >= 21 & hour < 24)
            {
                Console.WriteLine("Good Night");
            }
        }

        public static void Count24()
        {
            for(int i = 1; i <= 4; i++)
            {
                for (int j = 0; j <24; j += i)
                {
                    Console.Write($"{j},");
                }
                Console.Write("24\n");
            }
        }

        public static int[] CopyArray(int[] array1)
        {
            int len = array1.Length;
            int[] array2 = new int[len];

            for (int i = 0; i < len; i++)
            {
                array2[i] = array1[i];
            }

            return array2;
        }

        public static void list()
        {
            bool close = false;
            List<string> userlist = new List<string>();
            while (close == false)
            {
                Console.WriteLine("Enter command (+ item, - item, or -- to clear)):");
                StringBuilder input = new StringBuilder(Console.ReadLine());
                String command = input.ToString().Substring(0, 2);
                String item = input.Remove(0, 2).ToString();

                if (command == "--")
                {
                    userlist.Clear();
                }
                else if(command == "- ")
                {
                    userlist.Remove(item);
                }
                else if (command == "+ ")
                {
                    userlist.Add(item);
                }

                else
                {
                    Console.WriteLine("Incorrect command.");
                }

                foreach(string s in userlist)
                {
                    Console.Write(s);
                }
                Console.WriteLine();

                Console.WriteLine("Enter Yes to close the list:");
                string check = Console.ReadLine();
                if (check.ToLower() == "yes")
                {
                    close = true;
                }
            }
        }

        public static int[] FindPrimesInRange(int startNum, int endNum)
        {
            List<int> primeNums = new List<int>();
            for(int i = startNum; i <= endNum; i++)
            {
                int num = i / 2;
                bool isPrime = true;
                for(int j = 2; j <= num; j++)
                {
                    if(i%j == 0)
                    {
                        isPrime = false;
                        break;
                    }
                }
                if(isPrime == true)
                {
                    primeNums.Add(i);
                }
            }
            return primeNums.ToArray();
        }

        public static int[] rotateSum(int[] arr, int k)
        {
            int n = arr.Length;
            List<int> sum = new List<int>();
            List<int> rotate = new List<int>();
            for(int i = 0; i < n; i++)
            {
                sum.Add(0);
                rotate.Add(0);
            }

            for(int r = 1; r <= k; r++)
            {
                rotate[0] = arr[n - 1];

                for(int i = 1; i < n; i++)
                {
                    rotate[i] = arr[i-1];
                }
                arr = rotate.ToArray();

                for(int l = 0; l < n;l++)
                {
                    sum[l] += arr[l];
                }
            }

            return sum.ToArray();
        }

        public static int[] longestSequence(int[] arr)
        {
            if(arr.Length == 1)
            {
                return arr;
            }


            int count = 1;
            int maxLength = 0;
            int maxNum = 0;
            for(int i = 0; i < arr.Length - 2; i++)
            {
                if (arr[i] == arr[i + 1])
                {
                    count += 1;
                    if (maxLength < count)
                    {
                        maxLength = count;
                        maxNum = arr[i];
                    }
                }
                else
                {
                    count = 1;
                }
            }

            if(arr.Length >= 2)
            {
                if(arr[arr.Length - 1] == arr[arr.Length - 2])
                {
                    count += 1;
                    if (maxLength < count)
                    {
                        maxLength = count;
                        maxNum = arr[arr.Length - 1];
                    }
                }
                
            }

            List<int> result = new List<int>();
            for (int i = 0; i < maxLength; i++)
            {
                result.Add(maxNum);
            }

            return result.ToArray();
        }

        public static int mostFrequentNum(int[] arr)
        {
            Array.Sort(arr);
            int[] result = Chapter03Excercise03.longestSequence(arr);

            return result[0];
        }

        public static string reverse1(string str)
        {
            char[] arr = str.ToCharArray();
            Array.Reverse(arr);
            string result = new string(arr);
            return result;
        }

        public static void reverse2(string str)
        {
            for(int i = str.Length - 1; i >= 0; i--)
            {
                Console.Write(str[i]);
            }
        }

        public static void reverseSentence(string str)
        {
            char[] separator = { '.', ',', ':', ';', '=', '(', ')', '&', '[', ']', '\"', '\'', '/', '\\', '!', '?', ' ' };
            string[] strArr = str.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            
            List<string> strList = new List<string>();
            bool repeat = false;

            foreach(char a in str)
            {

                if (separator.Contains(a))
                {
                    if (repeat == true)
                    {
                        strList.Add(a.ToString());
                        continue;
                    }
                    strList.Add("word");
                    strList.Add(a.ToString());
                    repeat = true;
                }
                else
                {
                    repeat = false;
                }
            }

            int wordCount = strArr.Length-1;
            foreach(string s in strList)
            {
                if(s == "word")
                {
                    Console.Write(strArr[wordCount]);
                    wordCount--;
                }
                else
                {
                    Console.Write(s);
                }
            }

        }

        public static void palindromes(string str)
        {
            char[] separator = { '.', ',', ':', ';', '=', '(', ')', '&', '[', ']', '\"', '\'', '/', '\\', '!', '?', ' ' };
            string[] strArr = str.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            List<string> strList = new List<string>();
            Array.Sort(strArr);

            foreach(string word in strArr)
            {
                if (strList.Contains(word))
                {
                    continue;
                }

                bool isPalindrome = false;
                if(word.Length == 1)
                {
                    strList.Add(word);
                }
                else
                {
                    for(int i = 0; i < word.Length/2; i++)
                    {
                        if (word[i] != word[word.Length - 1 - i])
                        {
                            isPalindrome = false;
                        }
                        else
                        {
                            isPalindrome = true;
                        }
                    }
                    if(isPalindrome == true)
                    {
                        strList.Add(word);
                    }
                }
            }

            Console.WriteLine(String.Join(", ", strList));

        }

        public static List<string> parseURL(string url)
        {
            List<string> result = new List<string>();
            string Protocol;
            string Server;
            string Resource;

            if(url.Contains("://"))
            {
                string[] ProtocolAndRest = url.Split("://");
                Protocol = ProtocolAndRest[0];
                string ServerAndRest = ProtocolAndRest[1];

                if (ServerAndRest.Contains("/"))
                {
                    string[] ServerResource = ServerAndRest.Split("/");
                    Server = ServerResource[0];
                    Resource = ServerResource[1];
                } else
                {
                    Server = ServerAndRest;
                    Resource = "";
                }
            }else if (url.Contains("/"))
            {
                Protocol = "";
                string[] ServerRest = url.Split("/");
                Server = ServerRest[0];
                Resource = ServerRest[1];
            }
            else
            {
                Protocol = "";
                Server = url;
                Resource = "";
            }

            result.Add(Protocol);
            result.Add(Server);
            result.Add(Resource);

            return result;
        }

    }
}
