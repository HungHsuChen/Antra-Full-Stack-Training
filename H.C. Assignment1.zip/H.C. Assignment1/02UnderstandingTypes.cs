﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H.C._Assignment1
{
    class _02UnderstandingTypes
    {   
        public void PrintTypes ()
        {
            //sbyte, byte, short, ushort, int, uint, long,
            //ulong, float, double, and decimal.
            Console.WriteLine("sbyte takes 1 byte and has range -128 to 127");
            Console.WriteLine("byte takes 1 byte and has range 0 to 255");
            Console.WriteLine("short takes 2 byte and has range -32,768 to 32,767");
            Console.WriteLine("ushort takes 2 byte and has range 0 to 65,535");
            Console.WriteLine("int takes 4 byte and has range -2,147,483,648 to 2,147,483,647");
            Console.WriteLine("uint takes 4 byte and has range 0 to 4,294,967,295");
            Console.WriteLine("long takes 8 byte and has range -9,223,372,036,854,775,808 to 9,223,372,036,854,775,807");
            Console.WriteLine("ulong takes 8 byte and has range 0 to 18,446,744,073,709,551,615");
            Console.WriteLine("float takes 4 byte and has range ±1.0e-45 to ±3.4e38");
            Console.WriteLine("double takes 8 byte and has range ±5e-324 to ±1.7e308");
            Console.WriteLine("decimal takes 16 byte and has range ±1.0 × 10e-28 to ±7.9e28");
        }
        
    }
}
